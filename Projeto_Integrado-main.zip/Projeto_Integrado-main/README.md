## Projeto Integrado das disciplinas ***Construção de Software para WEB, Design e Desenvolvimento de Banco de Dados e Experiência e Interface com o Usuário.***

### Professores mentores do projeto

Professor   | Disciplina
:---------: | :------:
Otávio Lube dos Santos | Construção de Software para WEB
Abrantes Araújo Silva Filho | Design e Desenvolvimento de Banco de Dados
Susiléa Abreu dos Santos Lima  | Experiência e Interface com o Usuário

### Integrantes do projeto (UX Mavericks)
Aluno | GitHub | LinkedIn
:-----------------------:| :--------------: | :------------:
Guilherme Scarpelli Maia Leal | [![GitHub](https://img.shields.io/badge/github-black?style=for-the-badge&logo=github)](https://github.com/guisml) | [![LinkedIn](https://img.shields.io/badge/linkedin-blue?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/guilherme-scarpelli-06131716a/)
Gustavo Saraiva Mariano | [![GitHub](https://img.shields.io/badge/github-black?style=for-the-badge&logo=github)](https://github.com/saraivagustavo) | [![LinkedIn](https://img.shields.io/badge/linkedin-blue?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/gustavo-saraiva-222386235/)
Juan Escossia Pagan | [![GitHub](https://img.shields.io/badge/github-black?style=for-the-badge&logo=github)](https://github.com/juanep23) | [![LinkedIn](https://img.shields.io/badge/linkedin-blue?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/juanescossia/)
Lucas Girelli Bezerra | [![GitHub](https://img.shields.io/badge/github-black?style=for-the-badge&logo=github)](https://github.com/lucasgirelli09) | [![LinkedIn](https://img.shields.io/badge/linkedin-blue?style=for-the-badge&logo=linkedin)]()
Rafael Silveira de Melo | [![GitHub](https://img.shields.io/badge/github-black?style=for-the-badge&logo=github)](https://github.com/porousbunion8) | [![LinkedIn](https://img.shields.io/badge/linkedin-blue?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/rafael-silveira-de-melo-3b507226a/)

### Sobre o projeto:
> O projeto consiste desde a criação dos protótipos de alta fidelidade até o desenvolvimento das páginas web e implementação do banco de dados.
